﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Labor3
{
    class Program
    {
        static void Main(string[] args)
        {
            // TODO erstelle Netzwerk
            IPEndPoint initNode = NetworkCreator.InitNetwork();
            // TODO erstelle Logger
            Logger logger = new Logger();
            logger.Start(initNode);
        }
    }
}
